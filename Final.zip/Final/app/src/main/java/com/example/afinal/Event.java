package com.example.afinal;

public class Event {
    private String name;
    private String start_time;
    private String info_url;
    private String short_description;

    public Event(String name, String start_time, String info_url, String short_description) {
        this.name = name;
        this.start_time = start_time;
        this.info_url = info_url;
        this.short_description = short_description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getInfo_url() {
        return info_url;
    }

    public void setInfo_url(String info_url) {
        this.info_url = info_url;
    }

    public String getShort_description() {
        return short_description;
    }

    public void setShort_description(String short_description) {
        this.short_description = short_description;
    }
}
