package com.example.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class HomeActivity extends AppCompatActivity {
private RequestQueue requestQueue;
private TextView txtview;
private String selected_location;
private RadioButton malmi, pasila;
private EditText dStart, mStart, yStart, dEnd, mEnd, yEnd;
private ListView listView;
private EventListAdapter adapter;
private List<Event> mEvent;

@Override
protected void onCreate(Bundle savedInstanceState) {
        listView = (ListView) findViewById(R.id.listView);
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home);

        dStart = (EditText) findViewById(R.id.dStart);
        mStart = (EditText) findViewById(R.id.mStart);
        yStart = (EditText) findViewById(R.id.yStart);
        dEnd = (EditText) findViewById(R.id.dEnd);
        mEnd = (EditText) findViewById(R.id.mEnd);
        yEnd = (EditText) findViewById(R.id.yEnd);

        txtview = findViewById(R.id.text_view_result);
        Button button = findViewById(R.id.button_search);
        pasila = findViewById(R.id.Pasila_button);
        malmi = findViewById(R.id.Malmi_button);

        requestQueue = Volley.newRequestQueue(this);
        button.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View v) {
        jsonParse();
        }
        });
        }

private void jsonParse(){

    txtview.setText("");
        if (pasila.isChecked())
        {
        selected_location="pasila";
        }
        if (malmi.isChecked())
        {
        selected_location="malmi";
        }

        String dS = dStart.getText().toString();
        String mS = mStart.getText().toString();
        String yS = yStart.getText().toString();
        String dE = dEnd.getText().toString();
        String mE = mEnd.getText().toString();
        String yE = yEnd.getText().toString();

        String url = "https://api.hel.fi/linkedevents/v1/event/?start=" + yS + "-" + mS + "-" + dS + "&end=" + yE + "-" + mE + "-" + dE + "&?division="+selected_location;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
        new Response.Listener<JSONObject>() {
@Override
public void onResponse(JSONObject response) {
        try {
        JSONArray jsonArray = response.getJSONArray("data");
        //JSONArray jsonArray = response.getJSONArray("employees");

        for (int i = 0; i < jsonArray.length(); i++){
        JSONObject event = jsonArray.getJSONObject(i);
        String name = event.getString("name");
        String start_time = event.getString("start_time");
        String info_url = event.getString("info_url");
        String short_description = event.getString("short_description");

        /*mEvent = new ArrayList<>();
        mEvent.add(new Event(name, start_time, short_description, info_url));

        adapter = new EventListAdapter((getApplicationContext()),mEvent);
        listView.setAdapter(adapter);*/

        //txtview.append("Valitsit: " + selected_location);
        txtview.append("Date: " + start_time + "\n" + name + "\nShort description: " + short_description + "\nExtra Details: " + info_url + "\n\n");
        }

        } catch (JSONException e) {
        e.printStackTrace();
        }
        }
        }, new Response.ErrorListener() {
@Override
public void onErrorResponse(VolleyError error) {
        error.printStackTrace();
        }
        });

        requestQueue.add(request);
        }}