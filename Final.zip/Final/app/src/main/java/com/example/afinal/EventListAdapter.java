package com.example.afinal;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class EventListAdapter extends BaseAdapter {

    private Context mContext;
    private List<Event> mEventList;

    public int getCount() {
        return mEventList.size();
    }

    public EventListAdapter(Context mContext, List<Event> mEventList) {
        this.mContext = mContext;
        this.mEventList = mEventList;
    }

    @Override
    public Object getItem(int position) {
        return mEventList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = View.inflate(mContext, R.layout.activity_home, null);
        TextView tvNEvent = (TextView)v.findViewById(R.id.text_view_result);

        tvNEvent.setText(mEventList.get(position).getName() + "\n" + mEventList.get(position).getStart_time() + "\n" + mEventList.get(position).getShort_description() + "\n" + mEventList.get(position).getInfo_url());
        return v;
    }
}
